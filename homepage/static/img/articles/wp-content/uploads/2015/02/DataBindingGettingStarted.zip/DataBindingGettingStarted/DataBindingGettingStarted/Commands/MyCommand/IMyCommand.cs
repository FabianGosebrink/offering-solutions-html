﻿using System;

namespace DataBindingGettingStarted.Commands.MyCommand
{
    public interface IMyCommand
    {
        bool CanExecute(object parameter);
        void Execute(object parameter);
        event EventHandler CanExecuteChanged;
    }
}