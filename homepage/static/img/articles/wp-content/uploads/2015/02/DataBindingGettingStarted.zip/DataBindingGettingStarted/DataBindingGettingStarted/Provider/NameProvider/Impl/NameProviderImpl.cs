﻿using DataBindingGettingStarted.Common;

namespace DataBindingGettingStarted.Provider.NameProvider.Impl
{
    public class NameProviderImpl : NotifyPropertyChangedBase, INameProvider
    {
        private string _nameToDisplay;

        public string NameToDisplay
        {
            get
            {
                return _nameToDisplay;
            }
            set
            {
                _nameToDisplay = value;
                NotifyPropertyChanged();
            }
        }
    }
}
