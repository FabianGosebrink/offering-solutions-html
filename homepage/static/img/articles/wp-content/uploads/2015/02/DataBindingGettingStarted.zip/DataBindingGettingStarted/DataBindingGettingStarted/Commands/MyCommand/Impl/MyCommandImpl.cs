﻿using DataBindingGettingStarted.Provider.NameProvider;
using System;
using System.Windows.Input;

namespace DataBindingGettingStarted.Commands.MyCommand.Impl
{
    public class MyCommandImpl : ICommand, IMyCommand
    {
        private readonly INameProvider _nameProvider;

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            _nameProvider.NameToDisplay = "Hallelujah";
        }

        public MyCommandImpl(INameProvider nameProvider)
        {
            _nameProvider = nameProvider;
        }

        public event EventHandler CanExecuteChanged;
    }
}