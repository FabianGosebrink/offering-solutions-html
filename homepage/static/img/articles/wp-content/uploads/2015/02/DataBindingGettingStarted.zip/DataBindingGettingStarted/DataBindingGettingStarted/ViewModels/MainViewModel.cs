﻿using DataBindingGettingStarted.Commands.MyCommand;
using DataBindingGettingStarted.Commands.MyCommand.Impl;
using DataBindingGettingStarted.Provider.NameProvider;
using DataBindingGettingStarted.Provider.NameProvider.Impl;

namespace DataBindingGettingStarted.ViewModels
{
    public class MainViewModel
    {
        public INameProvider NameProvider { get; set; }
        public IMyCommand MyCommand { get; set; }

        public MainViewModel()
        {
            NameProvider = new NameProviderImpl();
            MyCommand = new MyCommandImpl(NameProvider);
        }
    }
}
