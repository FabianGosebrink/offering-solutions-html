﻿
namespace DataBindingGettingStarted.Provider.NameProvider
{
    public interface INameProvider
    {
        string NameToDisplay { get; set; }
    }
}
