app.controller('DemoController', function ($scope, chatService, cfpLoadingBar, flashService) {

	var _messages = [];
	
	cfpLoadingBar.start();
	var socket = io.connect('[YOUR_IP_AND_PORT]');
	
	
	var _sendMessage = function() {
	  cfpLoadingBar.start();
      chatService.sendMessage(socket, $scope.name, $scope.messageText);
	  $scope.messageText = "";
    };
	
	socket.on('chat', function (data) {        
		$scope.messages.push(data.name + ": " + data.text);
		$scope.$apply();
		 
		flashService.flashWindow(data.name + ": " + data.text, 10);
        $('body').scrollTop($('body')[0].scrollHeight);
		cfpLoadingBar.complete();
    });
 
    $scope.sendMessage = _sendMessage;
    $scope.messages = _messages;
	$scope.messageText = "";
	$scope.name = "";
});