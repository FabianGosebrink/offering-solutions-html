'use strict';
app.factory('chatService', function (chatDataService) {
    var chatService = {};

    var _sendMessage = function (socket, name, stringToSend) {
        return chatDataService.sendMessage(socket, name, stringToSend);
    };
	
    // public interface
    chatService.sendMessage = _sendMessage;

    return chatService;
});

app.factory('chatDataService', function ($http) {
     var chatDataService = {};

	   var _sendMessage = function (socket, name, stringToSend) {
          socket.emit('chat', { name: name, text: stringToSend });
      };

    chatDataService.sendMessage = _sendMessage;
	
    return chatDataService;
});
