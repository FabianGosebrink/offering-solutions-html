var app = angular.module('MessengerApp', ['ngRoute', 'ngResource', 'ui.bootstrap','chieffancypants.loadingBar']);
app.config(function ($routeProvider) {
    $routeProvider
    .when("", { controller: "DemoController", templateUrl: "./views/index.html" })
    .otherwise({ redirectTo: "/" });
});