﻿using WpfViewModelAsFacade.Services;

namespace WpfViewModelAsFacade
{
    public class MainViewModel
    {
        private readonly ICalculationService _calculationService;
        //other Properties here...

        public ICalculationService CalculationService
        {
            get { return _calculationService; }
        }

        public MainViewModel()
        {
            _calculationService = new CalculationService();
        }
    }
}
