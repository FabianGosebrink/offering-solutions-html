﻿namespace WpfViewModelAsFacade.Services
{
    public interface ICalculationService
    {
        int CalculatedNumber { get; }
    }
}