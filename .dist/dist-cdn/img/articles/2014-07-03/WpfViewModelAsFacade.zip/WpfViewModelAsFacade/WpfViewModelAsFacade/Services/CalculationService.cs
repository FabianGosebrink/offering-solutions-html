﻿
namespace WpfViewModelAsFacade.Services
{
    public class CalculationService : ICalculationService
    {
        public int CalculatedNumber { get; private set; }

        public CalculationService()
        {
            // Do some stuff here and get the result in the defined property
            CalculatedNumber = 25;
        }
    }
}
